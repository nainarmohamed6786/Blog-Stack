const express=require('express');
const User=require('../models/User');
const bcrypt=require('bcrypt');
const PostsSchema = require('../models/Post');

const router=express.Router();

//update a user

router.put('/:id',async(req,res)=>{
    if(req.body.userId==req.params.id){
        if(req.body.password){
            const salt=await bcrypt.genSalt(10);
            const hash=await bcrypt.hash(req.body.password,salt);
        }
        try{
            const updatedUser=await User.findByIdAndUpdate(req.params.id,{$set:req.body},{new:true});
            res.status(200).json(updatedUser);
        }
        catch(err){
           res.status(400).json("you can update only your account");
        }
    }
    else{
        res.status(400).json('you can updated only your account')
    }
});

//delete a user

router.delete('/:id',async(req,res)=>{
    if(req.body.userId==req.params.id){
    try{
     const user=await User.findById(req.params.id);
     try{

        await PostsSchema.deleteMany({username:user.username});

        await User.findByIdAndDelete(req.params.id);

        res.status(200).json("user Deleted successfully");
     }
     catch(err){
        res.status(400).json("User can't deleted");
     }
    }
    catch(err){
        res.status(400).json("user not found");
    }
    }
    else{
        res.status(400).json("You only deleted for your account")
    }
});


//get user

router.get('/',async(req,res)=>{
    try{
        const getUser=await User.find();
        res.status(200).json(getUser);
    }
    catch(err){
        res.status(400).json("You can't get users details")
    }
});

router.get('/:id',async(req,res)=>{
    try{
        const get=await User.findById(req.params.id);
        res.status(200).json(get)
    }
    catch(err){
        res.status(400).json(err)
    }
})

module.exports=router;