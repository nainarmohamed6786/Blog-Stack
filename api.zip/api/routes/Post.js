const express=require('express');
const User=require('../models/User');
const bcrypt=require('bcrypt');
const PostsSchema = require('../models/Post');

const router=express.Router();


//create a post

router.post('/',async(req,res)=>{
    const newPost=new PostsSchema(req.body);
    try{
       const savedPost=await newPost.save();
       res.status(200).json(savedPost);
    }
    catch(err){
        res.status(400).json("Post not created")
    }
});

//update a post

router.put('/:id',async(req,res)=>{
    try{
        const post=await PostsSchema.findById(req.params.id);
        if(post.username==req.body.username){
            try{
                const updatedPost=await PostsSchema.findByIdAndUpdate(req.params.id,{
                    $set:req.body
                },{new:true});

                res.status(200).json(updatedPost);
            }
            catch(err){
                res.status(400).json("updated post can't value")
            }
        }
    }
    catch(err){
        res.status(400).json("you upaded only your post")
    }
})

//delete a post

router.delete('/:id',async(req,res)=>{
    try{
  const post=await PostsSchema.findById(req.params.id);
  if(post.username==req.body.username){
try{
await PostsSchema.findByIdAndDelete(req.params.id);
res.status(200).json("Delete a post")
}
catch(err){
res.status(400).json("don't delete a post")
}
  }
  else{
    res.status(400).json("username can't valid");
  }

    }
    catch(err){
        res.status(400).json("You only delete your account")
    }
})

//get user

router.get("/", async (req, res) => {
    const username = req.query.user;
    const catName = req.query.cat;
    try {
      let posts;
      if (username) {
        posts = await PostsSchema.find({ username });
      } else if (catName) {
        posts = await PostsSchema.find({
          categories: {
            $in: [catName],
          },
        });
      } else {
        posts = await PostsSchema.find();
      }
      res.status(200).json(posts);
    } catch (err) {
      res.status(500).json(err);
    }
  }); 


router.get('/:id',async(req,res)=>{
    try{
        const get=await PostsSchema.findById(req.params.id);
        res.status(200).json(get)
    }
    catch(err){
        res.status(400).json(err)
    }
})

module.exports=router;