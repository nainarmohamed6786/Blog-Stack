const mongoose=require('mongoose');

const PostSchema=new mongoose.Schema({
    title:{
        type:String,
        required:true,
        unique:true
    },
    category:{
        type:Array,
        required:false,
    },
    desc:{
        type:String,
        required:true
    },
    photo:{
        type:String,
       required:false
    },
    username:{
        type:String,
        required:true
    }
},{timestamps:true});


const PostsSchema=mongoose.model("PostSchema",PostSchema);

module.exports=PostsSchema;